import os
import glob
import pandas as pd
from tkinter import Tcl
os.chdir("/home/abel/Desktop/Sneha-work/NEW-STUFF-WITH-ISR/combine")

extension = 'csv'
all_filenames = [i for i in glob.glob('*.{}'.format(extension))]

print(all_filenames)

print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")
print("\n")

all_filenames = Tcl().call('lsort','-dict',all_filenames)
print(all_filenames)
combined_csv = pd.concat([pd.read_csv(f) for f in all_filenames])
combined_csv.to_csv("combined_csv.csv", index=False, encoding='utf-8-sig')
