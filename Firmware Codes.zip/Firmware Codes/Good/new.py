import os
import sys
import csv


def isregister(reg):
	arr = ['ACC','AH','AL','XAR0','XAR1','XAR2','XAR3','XAR4','XAR5','XAR6','XAR7','AR0','AR1','AR2','AR3','AR4','AR5','AR6','AR7','DP','IFR','IER','DBGIER','P','PH','PL','PC','RPC','SP','ST0','ST1','XT','T','TL']
	for i in range(0, len(arr)):
		if reg == arr[i]:
			return 1
	return 0

def isalphabet(var):
	arr = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
	for i in range(0, len(arr)):
		if var == arr[i]:
			return 1
	return 0

def isspecialsymbol(var):
	arr1 = ['@','#','$','%','&','*','~']
	for i in range(0, len(arr1)):
		if var == arr1[i]:
			return 1
	return 0

def checkarray(array, stringcomp):
	for i in range(0, len(array)):
		if stringcomp == array[i]:
			return 1
	return 0

def checksl(array, pos,length):
	keeppos = 0
	para1 = ''
	para2 = ''
	counter = 0
	if length == 1:
		keeppos = pos + 10
	else:
		keeppos = pos + 9
	while array[keeppos] != ',':
		keeppos += 1
		para1 = para1 + array[keeppos]
	keeppos += 2
	while array[keeppos] != ' ':
		para2 = para2 + array[keeppos]
		keeppos += 1
	#print(para1)
	#print(para2)
	#print('-----------------------------------')	
	if isregister(para1) and not isregister(para2):
		return 0
	elif not isregister(para1) and isregister(para2):
		return 1
	elif isregister(para1) and isregister(para2):
		return 0
	elif isalphabet(para1[0]) and isspecialsymbol(para2[0]):
		return 0
	elif isspecialsymbol(para1[0]) and isalphabet(para2[0]):
		return 1
	elif isspecialsymbol(para1[0]) and para2[0] == '#':
		return 1
	return 0;




#os.system("objdump -j .text -D SolarMicroInv_F2803x.out > asm2.txt")

f=open("good.txt", "r")
numint = 50
exe = 'out-new.csv'

if f.mode == 'r':
	contents = f.read()


arithmetic = ['ADDB', 'ADRK','SBRK','SUBB','ADD','SUB','SUBR','ADDCU','ADDU','SBBU','SUBU','ADDL','ADDCL','ADDUL','ADDL',
'SUBBL','SUBCU','SUBCUL','SUBL','SUBRL','SUBUL','DMAC','MAC','MPY','MPYA','MPYB','MPYS','MPYU','MPYXU','SQRA','SQRS',
'XMAC','XMACD','IMACL','IMPYAL','IMPYL','IMPYSL','IMPYXUL','QMACL','QMPYAL','QMPYL','QMPYSL','QMPYUL','QMPYXUL','DEC',
'INC']

load = ['MOV','MOVB','MOVL','MOVZ','MOVW','MOVU','ZALR','ABSTC','MOVA','MOVAD','MOVX','PREAD']

store = ['MOV','MOVL','MOVB','MOVU', 'PREAD']

branchorjump = [' B ', 'BANZ','BAR',' BF ','FFC',' LB ', ' LC ', 'LCR',' SB ', 'SBF', ' XB ', 'XBANZ', 'XCALL']

multiinstruction = ['MOVDL','MOVP','MOVS']


boolean = ['AND','ANDB','NOT',' OR ','ORB','XOR','XORB']

othercommands = ['CMPR','POP','PUSH','ASR','CMP','CMPB','FLIP','LSL','LSR','MAX','MIN','NEG',
'SXTB','MOVH','ABS','ASRL','CMPL','CSB','LSRL','LSLL','MAXL','MINL','NORM','NEGTC','ROL','ROR',
'SAT,''SFR','TEST','ASR64','CMP64','LSL64','NEG64','SAT64','MAXCUL','MINCUL','DMOV','TBIT','TCLR','TSET','IN','OUT','UOUT',
'PWRITE','XPREAD','XPWRITE','IRET', 'LOOPZ','LOOPNZ', 'LRET','LRETE','LRETR', 'RPT','XRET', 'XRETC', 'IACK', 'INTR','TRAP',
'CLRC','C28ADDR','CLRC','C27OBJ', 'CLRC', 'C27MAP', 'ZAP', 'DINT', 'EINT', 'SETC', 'C28MAP', 'C28OBJ', 'LPADDR', 'SPM', 'ABORTI',
'ASP','EALLOW','IDLE','NASP','NOP','ZAPA','EDIS','ESTOP0','ESTOP1']


#MOV ->LOAD AND STORE
#MOVL -> LOAD AND STORE
#MOVB
#MOVU




totalint = 0;
numa = 0;
numb = 0;
nums = 0
numl = 0;
numx = 0;



lastinstruction = -1
thisinstruction = -1

numbb = 0;
numbl = 0;
numbs = 0;
numba = 0;
numbx = 0;
numll = 0;
numlb = 0;
numls = 0;
numla = 0;
numlx = 0;
numss = 0;
numsb = 0;
numsl = 0;
numsa = 0;
numsx = 0;
numaa = 0;
numab = 0;
numal = 0;
numas = 0;
numax = 0;
numxx = 0;
numxb = 0;
numxl = 0;
numxs = 0;
numxa = 0;


checkprevious = -1
j = 0
checkposition = 0
checkposition1 = 0
temp = ''
temp1 = ''
temp2 = ''
temp3 = ''
temp4 = ''
ans = 0
ans1 = 0
ans2 = 0
ans3 = 0
ans4 = 0
ans5 = 0
ans6 = 0
ans7 = 0
ans8 = 0
ans9 = 0
ans10 = 0
ans11 = 0
ans12 = 0
ans13 = 0
ans14 = 0
ans15 = 0
ans16 = 0
ans17 = 0
ans18 = 0
ans19 = 0
ans20 = 0
ans21 = 0
for i in contents:
	if j <= len(contents) - 7:	
		checkposition = 0
		checkposition1 = 0
		temp = ''
		temp1 = ''
		temp2 = ''
		temp3 = ''
		temp4 = ''
		ans = 0
		ans1 = 0
		ans2 = 0
		ans3 = 0
		ans4 = 0
		ans5 = 0
		ans6 = 0
		ans7 = 0
		ans8 = 0
		ans9 = 0
		ans10 = 0
		ans11 = 0
		ans12 = 0
		ans13 = 0
		ans14 = 0
		ans15 = 0
		ans16 = 0
		ans17 = 0
		ans18 = 0
		ans19 = 0
		ans20 = 0
		ans21 = 0
	
		temp = contents[j] + contents[j + 1] + contents[j + 2]
		temp1 = contents[j] + contents[j + 1] + contents[j + 2] + contents[j + 3]
		temp2 = contents[j] + contents[j + 1] + contents[j + 2] + contents[j + 3] + contents[j + 4]
		temp3 = contents[j] + contents[j + 1] + contents[j + 2] + contents[j + 3] + contents[j + 4] + contents[j + 5]
		temp4 = contents[j] + contents[j + 1] + contents[j + 2] + contents[j + 3] + contents[j + 4] + contents[j + 5] + contents[j + 6]
	
		ans = checkarray(arithmetic, temp)
		ans1 = checkarray(arithmetic, temp1)
		ans2 = checkarray(arithmetic, temp2)
		ans3 = checkarray(arithmetic, temp3)
		ans4 = checkarray(arithmetic, temp4)

		ans5 = checkarray(load, temp)
		ans6 = checkarray(load, temp1)
		ans7 = checkarray(load, temp2)

		ans8 = checkarray(store, temp)
		ans9 = checkarray(store, temp1)

		ans10 = checkarray(branchorjump, temp)
		ans11 = checkarray(branchorjump, temp1)
		ans12 = checkarray(branchorjump, temp2)

		ans13 = checkarray(multiinstruction, temp1)
		ans14 = checkarray(multiinstruction, temp2)

		ans15 = checkarray(othercommands, temp)
		ans16 = checkarray(othercommands, temp1)
		ans17 = checkarray(othercommands, temp2)
		ans18 = checkarray(othercommands, temp3)
		ans19 = checkarray(othercommands, temp4)

		ans20 = checkarray(boolean, temp)
		ans21 = checkarray(boolean, temp1)
		
		if ans4 == 1:
			ans3 = 0	
			ans2 = 0
			ans1 = 0
			ans = 0
		elif ans3 == 1:
			ans2 = 0	
			ans1 = 0
			ans = 0
		elif ans2 == 1:
			ans1 = 0
			ans = 0
		elif ans1 == 1:
			ans = 0
		if ans7 == 1:
			ans6 = 0
			an5 = 0
		elif ans6 == 1:
			ans5 = 0
		if ans9 == 1:
			ans8 = 0
		if ans12 == 1:
			ans11 = 0
			ans10 = 0
		elif ans11 == 1:
			ans10 = 0
		if ans14 == 1:
			ans13 = 0
		if ans19 == 1:
			ans18 = 0	
			ans17 = 0
			ans16 = 0
			ans15 = 0
		elif ans18 == 1:
			ans17 = 0	
			ans16 = 0
			ans15 = 0
		elif ans17 == 1:
			ans16 = 0
			ans15 = 0
		elif ans16 == 1:
			ans15 = 0
		if ans21 == 1:
			ans20 = 0

		if ans == 1 or ans1 == 1 or ans2 == 1 or ans3 == 1 or ans4 == 1: #arith
			numa += 1
			thisinstruction = 1
			checkprevious = 1                                         
		elif ans8 == 1 or ans9 == 1:					#store	
			if ans8 == 1:
				checkposition = j + 2
				checkposition1 = 1
			else:
				checkposition = j + 3
				checkposition1 = 2		
			if(checksl(contents,checkposition,checkposition1)):       #is store
				nums += 1
				thisinstruction = 3
			else:
				numl += 1
				thisinstruction = 2
			checkprevious = 1             				 
		elif ans5 == 1 or ans6 == 1 or ans7 == 1:                         #load
			numl += 1
			thisinstruction = 2
			checkprevious = 1 					
		elif ans10 == 1 or ans11 == 1 or ans12 == 1:                      #branchjump
			numb += 1
			thisinstruction = 4
			checkprevious = 1   					
		elif ans20 == 1 or ans21 == 1:                                    #boolean
			numx += 1
			thisinstruction = 5
			checkprevious = 1
		elif ans13 == 1 or ans14 == 1:                                   #multiinstruction
			if temp2 == 'MOVDL':
				nums += 1
				if lastinstruction == 5:
					numxs += 1
				elif lastinstruction == 4:
					numbs += 1
				elif lastinstruction == 3:
					numss += 1
				elif lastinstruction == 2:
					numls += 1
				elif lastinstruction == 1:
					numas += 1
				numl += 1
				numsl += 1
				thisinstruction = 2	
				lastinstruction = 0			 
			elif temp1 == 'MOVP':
				numl += 1
				if lastinstruction == 5:
					numxl += 1	
				elif lastinstruction == 4:
					numbl += 1
				elif lastinstruction == 3:
					numsl += 1
				elif lastinstruction == 2:
					numll += 1
				elif lastinstruction == 1:
					numal += 1			
				nums += 1
				numls += 1
				thisinstruction = 3
				lastinstruction = 0	
			elif temp1 == 'MOVS':
				numl += 1
				if lastinstruction == 5:
					numxl += 1
				elif lastinstruction == 4:
					numbl += 1
				elif lastinstruction == 3:
					numsl += 1
				elif lastinstruction == 2:
					numll += 1
				elif lastinstruction == 1:
					numal += 1				
				numa += 1
				numla += 1
				thisinstruction = 1
				lastinstruction = 0	
			checkprevious = 1         			  
		elif ans15 == 1 or ans16 == 1 or ans17 == 1 or ans18 == 1 or ans19 == 1:    #other
			thisinstruction = 6
			checkprevious = 1
			                                       			


	#a1 l2 s3 bj4
	if checkprevious == 1:
		totalint = totalint + 1
		if lastinstruction == 5 and thisinstruction == 5:
			numxx += 1
		elif lastinstruction == 5 and thisinstruction == 4:
			numxb += 1
		elif lastinstruction == 5 and thisinstruction == 3:
			numxs += 1
		elif lastinstruction == 5 and thisinstruction == 2:
			numxl += 1
		elif lastinstruction == 5 and thisinstruction == 1:
			numxa += 1
		elif lastinstruction == 4 and thisinstruction == 5:
			numbx += 1
		elif lastinstruction == 4 and thisinstruction == 4:
			numbb += 1
		elif lastinstruction == 4 and thisinstruction == 2:
			numbl += 1
		elif lastinstruction == 4 and thisinstruction == 3:
			numbs += 1
		elif lastinstruction == 4 and thisinstruction == 1:
			numba += 1
		elif lastinstruction == 3 and thisinstruction == 5:
			numsx += 1
		elif lastinstruction == 3 and thisinstruction == 3:
			numss += 1
		elif lastinstruction == 3 and thisinstruction == 4:
			numsb += 1
		elif lastinstruction == 3 and thisinstruction == 2:
			numsl += 1
		elif lastinstruction == 3 and thisinstruction == 1:
			numsa += 1
		elif lastinstruction == 2 and thisinstruction == 5:
			numlx += 1
		elif lastinstruction == 2 and thisinstruction == 2:
			numll += 1
		elif lastinstruction == 2 and thisinstruction == 4:
			numlb += 1
		elif lastinstruction == 2 and thisinstruction == 3:
			numls += 1
		elif lastinstruction == 2 and thisinstruction == 1:
			numla += 1
		elif lastinstruction == 1 and thisinstruction == 5:
			numax += 1
		elif lastinstruction == 1 and thisinstruction == 4:
			numab += 1
		elif lastinstruction == 1 and thisinstruction == 2:
			numal += 1
		elif lastinstruction == 1 and thisinstruction == 3:
			numas += 1
		elif lastinstruction == 1 and thisinstruction == 1:
			numaa += 1
		lastinstruction = thisinstruction
		checkprevious = -1
	j += 1
	if totalint == numint:
		totalint = 0
		myData = [[numa,numb,nums,numl,numx,numbx,numbb,numbl,numbs,numba,numlx, numll,numlb,numls,numla,numsx, numss,numsb,numsl,numsa,numax,numaa,numab,numal,numas, numxx, numxl,numxs,numxl,numxa]]
		with open(exe, 'a') as myFile:
			writer = csv.writer(myFile)
			writer.writerows(myData)
		'''
		print("arithmetic: ", numa)
		print("branch: ", numb)
		print("store: ", nums)
		print("load: ", numl)
		print("branchbranch: ", numbb)
		print("branchload: ", numbl)
		print("branchstore: ", numbs)
		print("brancharithmetic: ", numba)
		print("loadload: ", numll)
		print("loadbranch: ", numlb)
		print("loadstore: ", numls)
		print("loadarithmetic: ", numla)
		print("storestore: ", numss)
		print("storebranch: ", numsb)
		print("storeload: ", numsl)
		print("storearithmetic: ", numsa)
		print("arithmeticarithmetic: ", numaa)
		print("arithmeticbranch: ", numab)
		print("arithmeticload: ", numal)
		print("arithmeticstore: ", numas)
		'''		
		numa = 0;
		numb = 0;
		nums = 0;
		numl = 0;
		numx = 0;
		numbx = 0;
		numbb = 0;
		numbl = 0;
		numbs = 0;
		numba = 0;
		numlx = 0;
		numll = 0;
		numlb = 0;
		numls = 0;
		numla = 0;
		numsx = 0;
		numss = 0;
		numsb = 0;
		numsl = 0;
		numsa = 0;
		numax = 0;
		numaa = 0;
		numab = 0;
		numal = 0;
		numas = 0;
		numxx = 0;
		numxb = 0;
		numxl = 0;
		numxs = 0;
		numxa = 0;




row_contents = ['numa','numb','nums','numl','numx','numbx','numbb','numbl','numbs','numba','numlx','numll','numlb','numls','numla','numsx', 'numss','numsb','numsl','numsa','numax','numaa','numab','numal','numas','numxx','numxl','numxs','numxl','numxa']



with open(exe, "r") as infile:
	reader = list(csv.reader(infile))
	reader.insert(0, row_contents)

with open(exe, "w", newline='') as outfile:
	writer = csv.writer(outfile)
	for line in reader:
		writer.writerow(line)





















